CREATE PROCEDURE `PrintSaleOfComponents`()
  BEGIN
SELECT * FROM new_schema.saleofcomponents;
END