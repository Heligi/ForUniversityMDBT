CREATE PROCEDURE `PrintStock`()
  BEGIN
SELECT * FROM new_schema.stock;
END