CREATE PROCEDURE `PrintCity`()
  BEGIN
SELECT * FROM new_schema.city;
END