CREATE PROCEDURE `PrintAccessories`()
  BEGIN
SELECT * FROM new_schema.accessories;
END