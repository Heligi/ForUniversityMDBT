CREATE PROCEDURE `PrintcCustomer`()
  BEGIN
SELECT * FROM new_schema.customer;
END