CREATE PROCEDURE `PrintManufacturer`()
  BEGIN
SELECT * FROM new_schema.manufacturer;
END